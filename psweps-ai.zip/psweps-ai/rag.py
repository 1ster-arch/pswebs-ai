import re
import math
from pathlib import Path
from collections import Counter

KNOWLEDGE_DIR = Path("knowledge")


def _read_all():
    docs = []
    if not KNOWLEDGE_DIR.exists():
        print(f"[rag] WARNING: {KNOWLEDGE_DIR} folder not found")
        return docs
    for pattern in ("**/*.md", "**/*.txt"):
        for p in KNOWLEDGE_DIR.glob(pattern):
            try:
                text = p.read_text(encoding="utf-8", errors="replace")
                docs.append((p.name, text))
                print(f"[rag] Loaded {p.name} ({len(text)} chars)")
            except Exception as e:
                print(f"[rag] Failed to read {p}: {e}")
    return docs


def _chunk(text, source, max_chars=900):
    parts = re.split(r"\n(?=#{1,6}\s)|\n\s*\n", text)
    chunks, buf = [], ""
    for part in parts:
        part = part.strip()
        if not part:
            continue
        if len(buf) + len(part) + 2 <= max_chars:
            buf = (buf + "\n\n" + part).strip()
        else:
            if buf:
                chunks.append((source, buf))
            buf = part
    if buf:
        chunks.append((source, buf))
    return chunks


def _tokenize(s):
    return re.findall(r"[a-z0-9]+", s.lower())


def retrieve(query, top_k=4):
    docs = _read_all()
    chunks = []
    for name, text in docs:
        chunks.extend(_chunk(text, name))

    if not chunks:
        print("[rag] No chunks found — knowledge folder empty?")
        return []

    q_tokens = set(_tokenize(query))
    if not q_tokens:
        return []

    N = len(chunks)
    df = Counter()
    chunk_tokens = []
    for _, c in chunks:
        toks = _tokenize(c)
        chunk_tokens.append(toks)
        for t in set(toks):
            df[t] += 1

    avg_len = sum(len(t) for t in chunk_tokens) / max(N, 1)
    k1, b = 1.5, 0.75

    scored = []
    for i, toks in enumerate(chunk_tokens):
        tf = Counter(toks)
        L = len(toks) or 1
        score = 0.0
        for q in q_tokens:
            if q not in tf:
                continue
            idf = math.log(1 + (N - df[q] + 0.5) / (df[q] + 0.5))
            score += idf * (tf[q] * (k1 + 1)) / (tf[q] + k1 * (1 - b + b * L / avg_len))
        if score > 0:
            scored.append((score, chunks[i]))

    scored.sort(key=lambda x: -x[0])
    return [(src, txt) for _, (src, txt) in scored[:top_k]]