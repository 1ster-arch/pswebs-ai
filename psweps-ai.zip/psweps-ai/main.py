import os
import json
import logging
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse, HTMLResponse
from pydantic import BaseModel, field_validator
from typing import List
import httpx
from dotenv import load_dotenv

from rag import retrieve

load_dotenv()

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("psweps")

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
MODEL = "deepseek/deepseek-v4-flash"
SITE_URL = os.getenv("SITE_URL", "http://localhost:8000")
SITE_NAME = "PSWEPS AI Prototype"

REFUSAL = (
    "I don't have verified information on that in my PSWEPS knowledge base. "
    "Please contact PSWEPS directly:\n"
    "• Email: info@psweps.gov.gh or support@psweps.gov.gh\n"
    "• Phone/WhatsApp: +233 55 452 8198 / +233 50 644 5203"
)

BASE_PROMPT = """You are the PSWEPS Member AI assistant. You answer ONLY from the PSWEPS CONTEXT below.

ABSOLUTE RULES (cannot be broken):
1. PSWEPS is in GHANA. Never say Kenya, Uganda, Nigeria, Nairobi or any other country.
2. PSWEPS = Public Sector Workers Employees' Pension Scheme (Ghana).
3. Use ONLY the PSWEPS CONTEXT below. Nothing else. Not your training data. Not general knowledge.
4. If the answer is not explicitly stated in the context, reply with EXACTLY this and nothing else:
   "{refusal}"
5. Do not speculate, infer, summarize beyond the context, or fill gaps.
6. Do not mention that you are an AI, a language model, or that you have training data.
7. Use markdown for formatting: **bold** for key terms, and "- " for bullet points when listing multiple items.
8. Do NOT include a "Source:" line. Do not cite documents.

=== PSWEPS CONTEXT ===
{context}
=== END PSWEPS CONTEXT ===

REMINDER: Only answer from the context. PSWEPS is in Ghana. If unsure, use rule 4 verbatim.
"""

IDENTITY_KEYWORDS = (
    "psweps", "where", "country", "located", "location",
    "office", "address", "ghana", "headquarters", "based",
)


def build_context(user_query: str):
    hits = retrieve(user_query, top_k=5)
    q_lower = user_query.lower()
    if any(k in q_lower for k in IDENTITY_KEYWORDS):
        extra = retrieve("PSWEPS Ghana identity country location office address", top_k=2)
        seen = {(s, t[:80]) for s, t in hits}
        for s, t in extra:
            if (s, t[:80]) not in seen:
                hits.append((s, t))
    return hits


app = FastAPI(title="PSWEPS AI Prototype")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000", "http://127.0.0.1:8000"],
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)


class Message(BaseModel):
    role: str
    content: str

    @field_validator("content")
    @classmethod
    def limit(cls, v):
        if len(v) > 2000:
            raise ValueError("Message too long (max 2000 characters)")
        return v


class ChatRequest(BaseModel):
    messages: List[Message]


@app.get("/")
def root():
    if os.path.exists("index.html"):
        return FileResponse("index.html")
    return HTMLResponse("<h2>PSWEPS AI API is running.</h2><p>Place an <code>index.html</code> file in this folder or access <a href='/docs'>/docs</a>.</p>")


@app.get("/health")
def health():
    return {"status": "ok", "model": MODEL, "key_set": bool(OPENROUTER_API_KEY)}


@app.get("/debug/retrieve")
def debug_retrieve(q: str = ""):
    hits = retrieve(q, top_k=5)
    return {
        "query": q,
        "num_hits": len(hits),
        "hits": [{"source": s, "preview": t[:400]} for s, t in hits],
    }


def _prepare(user_query: str):
    hits = build_context(user_query)
    if not hits:
        log.info("NO HITS for query=%r → refusal", user_query)
        return None, None, REFUSAL
    sources = sorted({s for s, _ in hits})
    log.info("AUDIT query=%r sources_used=%s", user_query, sources)
    context = "\n\n---\n\n".join(f"[{src}]\n{chunk}" for src, chunk in hits)
    return hits, context, None


@app.post("/chat")
async def chat(req: ChatRequest):
    if not OPENROUTER_API_KEY:
        raise HTTPException(500, "OPENROUTER_API_KEY not set")

    last_user = next((m.content for m in reversed(req.messages) if m.role == "user"), "")
    _, context, refusal = _prepare(last_user)
    if refusal:
        return {"reply": refusal}

    system_prompt = BASE_PROMPT.format(context=context, refusal=REFUSAL)
    payload = {
        "model": MODEL,
        "messages": [{"role": "system", "content": system_prompt}]
        + [m.model_dump() for m in req.messages],
    }
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
        "HTTP-Referer": SITE_URL,
        "X-Title": SITE_NAME,
        "X-OpenRouter-Cache": "true",
    }

    async with httpx.AsyncClient(timeout=90) as client:
        r = await client.post(OPENROUTER_URL, json=payload, headers=headers)

    if r.status_code != 200:
        raise HTTPException(r.status_code, r.text)
    data = r.json()
    try:
        reply = data["choices"][0]["message"]["content"]
    except (KeyError, IndexError):
        raise HTTPException(502, f"Unexpected response: {data}")
    return {"reply": reply}


@app.post("/chat/stream")
async def chat_stream(req: ChatRequest):
    if not OPENROUTER_API_KEY:
        raise HTTPException(500, "OPENROUTER_API_KEY not set")

    last_user = next((m.content for m in reversed(req.messages) if m.role == "user"), "")
    _, context, refusal = _prepare(last_user)

    if refusal:
        async def refusal_gen():
            yield f"data: {json.dumps({'delta': refusal})}\n\n"
            yield "data: [DONE]\n\n"
        return StreamingResponse(refusal_gen(), media_type="text/event-stream")

    system_prompt = BASE_PROMPT.format(context=context, refusal=REFUSAL)
    payload = {
        "model": MODEL,
        "stream": True,
        "messages": [{"role": "system", "content": system_prompt}]
        + [m.model_dump() for m in req.messages],
    }
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
        "HTTP-Referer": SITE_URL,
        "X-Title": SITE_NAME,
        "X-OpenRouter-Cache": "true",
    }

    async def event_gen():
        try:
            async with httpx.AsyncClient(timeout=120) as client:
                async with client.stream("POST", OPENROUTER_URL, json=payload, headers=headers) as r:
                    if r.status_code != 200:
                        err = await r.aread()
                        yield f"data: {json.dumps({'error': err.decode(errors='replace')})}\n\n"
                        yield "data: [DONE]\n\n"
                        return
                    async for line in r.aiter_lines():
                        if not line or not line.startswith("data: "):
                            continue
                        chunk = line[6:].strip()
                        if chunk == "[DONE]":
                            break
                        try:
                            obj = json.loads(chunk)
                            delta = obj.get("choices", [{}])[0].get("delta", {}).get("content", "")
                            if delta:
                                yield f"data: {json.dumps({'delta': delta})}\n\n"
                        except Exception:
                            continue
        except Exception as e:
            log.exception("stream error")
            yield f"data: {json.dumps({'error': str(e)})}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(event_gen(), media_type="text/event-stream")


if __name__ == "__main__":
    import uvicorn
    print("Starting PSWEPS AI server at http://127.0.0.1:8000")
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)