# PSWEPS Governance, Board of Trustees, Secretariat and Service Providers

Source: psweps.gov.gh — About Board of Trustees / About PSWEPS

## Governance Structure
PSWEPS (Public Sector Workers Employees' Pension Scheme, Ghana) is governed by a Board of Trustees and supported by a Secretariat and approved external service providers. PSWEPS does not have a CEO; the highest office is the Chairperson of the Board of Trustees.

## Board of Trustees

- Cynthia Arthur (Mrs.) — Chairperson. Economist and financial sector strategist; over two decades of leadership experience at Ghana's Ministry of Finance.
- Mr. Kizito Dorzie Ballans — Vice Chairman (appointed May 2021).
- Mr. Martin Luke-Tay — Independent Trustee. Finance and risk management professional, 25+ years.
- Mrs. Helen Akpene Awo Ziwu (Esq) — Member. Solicitor-General of the Republic of Ghana.
- Dr. Audrey Smock Amoah — Member. Development planning professional.
- Mr. Bernard Adjei — Member. General Secretary of the Public Services Workers' Union (PSWU).
- Ms. Georgina Smedley — Member.
- Mr. Prince Obeng-Himah — Member. Education professional, 30+ years of service.
- Mr. Victor Owusu — Independent Trustee.
- Mr. Kwabena Afum Dankwa — Member.
- Mr. Carlis Brako — Member.
- Mr. Mark Brookman-Amissah — Member.
- Mr. David Lartey Quarcoopome — Member.
- Mr. Patrick Sebe Soadwa — Member.
- Mr. Isaac Richmond Mensah — Member.
- Dr. Charles Kessey — Member.
- Naa Alhaji Ali Seidu Pelpuo Yelmaana — Member.

## Secretariat
- Ms. Philipina Asare — Secretary.
- Mr. Adam Muhazu — Data & Portfolio Analyst.
- Miss Loretta Asare — Client Relationship Officer.

## Service Providers
- Scheme Administrator: General Trust Company Limited.
- Fund Managers: Bora Capital Advisors Limited and SDC Capital Limited.
- Custodian: Fidelity Bank Ghana Limited.
- Independent Auditor: Arveyetey & Associates.