# PSWEPS — Identity & Country

PSWEPS = **Public Sector Workers Employees' Pension Scheme**.
Country: **Ghana** (Republic of Ghana). Never Uganda, Nigeria, Kenya, or any other country.
Also known as "PSW Employee Pension Scheme" (NPRA register) and "PSW Employees Occupational Pension Scheme" (NPRA Pensions Digest).
Established: January 2018 (registered with NPRA; 15 Trustees inaugurated; Mrs. Cynthia Arthur appointed Chairperson).
Legal framework: National Pensions Act, 2008 (Act 766); amended by Act 883 (2014) and Act 1091 (2023); plus L.I. 1990 (Occupational and Personal Pension Schemes Regulations, 2011).
Regulator: National Pensions Regulatory Authority (NPRA), Ghana.
Sponsor: Government of Ghana, c/o Ministry of Employment and Labour Relations.
Purpose: To consolidate public sector institutions that were without occupational schemes at the time of the Temporary Pension Fund Account (TPFA) transfer.
Scale (end-2025): 34,854 contributors; 76 contributing institutions; GH¢1.50 billion assets under management; 5,460 retirees/beneficiaries paid since inception.
Website: https://psweps.gov.gh
Source: PSWEPS Brochure 2025; 2023/2024/2025 Annual Reports; NPRA Pensions Digest 3rd Ed.

# PSWEPS — What It Manages (Tier 2 only)

PSWEPS manages **Tier 2 only** — the mandatory occupational pension tier.
Ghana's three-tier structure:
- Tier 1 — Basic National Social Security Scheme (BNSSS), defined benefit, managed by SSNIT. Rate: 13.5% of salary (employer 13%, employee 5.5%). Part goes to NHIS, remainder invested for pension.
- Tier 2 — Mandatory occupational, defined contribution, managed by licensed trustees. Rate: 5% of basic salary. PSWEPS is one of five public-sector Tier 2 schemes.
- Tier 3 — Voluntary personal/provident fund. PSWEPS does not manage Tier 3.
Total mandatory contribution: 18.5% of salary (13.5% Tier 1 + 5% Tier 2).
The other four public-sector Tier 2 schemes: Hedge (CLOGSAG), Health Sector, Ghana Education Service (GES), Judicial Service.
PSWEPS does NOT pay a monthly pension. Monthly pensions come from SSNIT (Tier 1). PSWEPS pays a lump sum.
Source: PSWEPS "Current Pension Structure in Ghana"; PSWEPS Brochure 2025; Act 766 s.100.

# PSWEPS — Who Is Eligible

Eligible: Staff of public institutions and subvented agencies that:
- Draw salaries through the Controller and Accountant-General's Department (CAGD), AND
- Are NOT covered by the four other public-sector Tier 2 schemes (Hedge/CLOGSAG, Health Sector, GES, Judicial Service).
Number of participating institutions: 74 (July 2020) → 72 (end-2023) → 76 (end-2025).
Not eligible: Workers already under Hedge, Health Sector, GES, or Judicial Service schemes. Private-sector workers. Police, Immigration, Prisons, Security & Intelligence Agencies, and Fire Service are excluded from the pension unification regime by Act 1091 (2023).
Registration: Employer-sponsored. Members register via the PSWEPS CRM portal at https://psweps.gov.gh → Members Login → Sign Up → enter Staff ID + SSNIT number → register → verify with Ghana Card (photo under 3MB) and SMS/email PIN.
Source: NPRA Pensions Digest; PSWEPS Client Service Charter; PSWEPS Brochure 2025; CRM Portal Guide.

# PSWEPS — Contributions

Rate: **5% of basic salary** (mandatory Tier 2 deduction).
Who pays: The employer deducts from the employee's salary and remits to the Scheme on the employee's behalf. Contributions are held in trust by the employer until remitted to the trustees.
Remittance deadline: Within **14 days from the end of each month** (Act 766 s.100(3)).
Received from: The Paymaster (CAGD) on behalf of contributors.
Vesting: Mandatory employer and employee contributions **vest immediately in the employee** (NPRA Pensions Digest).
Tax: Contributions are not taxed as income; benefits under the scheme are not taxable (Act 766 s.104).
Protection: Accrued Tier 2 benefits cannot be attached in execution of a judgment debt or pledged/assigned (Act 766 ss.102–103). A scheme may allow use of benefits to secure a mortgage for a primary residence.
Statutory penalty for late remittance: An employer who fails to remit within the stipulated time commits an offence, liable on summary conviction to a fine of 2,000 penalty units or 2 years' imprisonment, or both (Act 766 s.100(10)). A PSWEPS/Tier 2-specific late-interest formula is not published.
Confirmed flows: 2023: GH¢52.59m received; 2024: GH¢67.12m; 2025: GH¢89.45m (Chairperson's statement) — but the 2025 Summary Statistics page states GH¢71.16m. Prefer audited financial statements for totals.
What to do if a contribution is missing: Members should reconcile their monthly contributions on their statement against deductions on their pay slip, and contact PSWEPS immediately to address discrepancies.
Source: PSWEPS "Current Pension Structure in Ghana"; PSWEPS Brochure 2025; Act 766 s.100; 2023 Annual Report.

# PSWEPS — Benefits

Type: A single **lump sum** (defined contribution). No monthly pension, no annuity.
Calculation: Total paid-up monthly contributions PLUS investment returns MINUS administrative charges. PSWEPS does NOT use a defined benefit salary formula.
Qualifying conditions (Act 766 s.101):
1. Attaining retirement age (statutory retirement age in Ghana is 60).
2. Age 50+ and not employed or self-employed.
3. Permanent emigration of a non-citizen.
4. Medical-board retirement, total/permanent disability, or retirement before 50 under employment terms.
5. Death — full lump sum to nominated beneficiaries, or to persons specified in the scheme rules if none nominated.
Early retirement: Recognised by PSWEPS alongside statutory retirement.
Disability: Lump sum payable where a contributor is medically declared invalid or declared permanently unfit for work by a licensed medical practitioner.
Death benefits: Whole accrued benefit paid as lump sum to nominated beneficiaries, or persons specified in the scheme rules (Act 766 s.101(5)).
Processing standard: Benefit applications processed within **6 weeks**, subject to complete documentation.
Confirmed payments: 2023: GH¢17.45m paid to 683 members (average 25 working days); 2025: GH¢43.89m paid to 984 retirees/beneficiaries.
Historical note (2020): Interim 80% payment to 2020 public-sector retirees pending TPFA data resolution. Retirees could access the last 10 years of Tier 2 contributions while SSNIT paid the lump sum for earlier years as "past credit."
Source: PSWEPS "Current Pension Structure in Ghana"; PSWEPS Brochure 2025; Act 766 s.101; Client Service Charter; 2023 and 2025 Annual Reports; Retirees Payments Communiqué 2020.

# PSWEPS — How to Claim (Member Claim Form C1)

Requirements for a member withdrawal claim (verbatim from Form C1):
- A completely filled PSWEPS withdrawal form with account details.
- Front and back copy of Ghana (ECOWAS) Card.
- Form signed by employer / HR.
- Copy of retirement letter.
- Copies of last three (3) payslips.
- Copy of SSNIT Payment Advice / Statements.
- Copy of cheque leaf or bank statement.
Submit to: info@psweps.gov.gh or support@psweps.gov.gh, or deliver to the PSWEPS office in Osu, Accra.
Source: PSWEPS Member Claim Form C1.

# PSWEPS — How to Claim a Death Benefit (Beneficiary Claim Form B1)

Requirements (verbatim from Form B1):
- Cover letter from employer.
- Copy of death certificate.
- If the member listed beneficiaries on the (GENTRUST) Contributor Enrollment Form (CEF): payment is processed for listed beneficiaries.
- If not listed: beneficiary nomination from HR, plus account details and Ghana Card copies.
- If no beneficiaries were nominated: Letters of Administration / Probate (Will), executor contact details, ID copies, and letter of disbursement (allotted percentages).
- If a beneficiary is a minor: court declaration (by dependent), dependent's account details, passport picture, and birth certificate of the minor.
- Plus SSNIT payment advice and cheque leaf or Form A1.
Source: PSWEPS Beneficiary Claim Form B1.

# PSWEPS — Statements & Member Portal

Statements: Issued **quarterly**. Member data compiled, validated and processed quarterly; statements issued within two weeks after each quarter; uploaded to Scheme portals. Printed copies free on request.
Member CRM portal: https://psweps.gov.gh → "Members Login" → onlineportal.psweps.gov.gh/member/.
Sign-up: Enter Staff ID and SSNIT number; verify with Ghana Card (photo < 3MB); SMS/email PIN. Members can view statements and update details.
Administrator portal (historical): www.gentrustgh.com (GENTRUST). From 2025 the Scheme Administrator is Standard Pensions Trust Limited.
USSD / mobile app: Not currently available. Only web portals, WhatsApp contact numbers, and social media are documented.
Updating details: Members should promptly notify the Scheme of changes to personal details, employment status, or beneficiary information, including marital status, dependents or nominated beneficiaries.
Member education: Nationwide outreach and sensitisation engagements (e.g. Forestry Commission, Lands Commission, Grains and Legumes Board Kumasi, Ghana Police civilian staff, CSIR-Oil Palm, PSWU Kumasi).
Source: PSWEPS Brochure 2025; Client Service Charter; 2025 Annual Report; CRM Portal Guide.

# PSWEPS — Service Standards (Client Service Charter)

Contributions processing: Within 5 working days (subject to accurate schedules).
Account statements: Quarterly (2 weeks after quarter end) / 24 hours for ad-hoc requests.
Inquiries: 24 hours.
Benefits: 6 weeks, subject to complete documentation.
Transfers in/out: 4 weeks from receipt of complete transfer request.
Fund performance reporting: Annually via audited reports.
Member education: Periodic outreach.
All services are provided at **no direct cost** to members and institutions. Anyone demanding payment should be reported.
Complaints: Acknowledged within 24 hours; reviewed and resolved within 3–5 working days depending on complexity.
If PSWEPS misses a service standard, the client receives a written apology and expedited processing. Proven financial loss caused by the Scheme's failure shall be reviewed for possible compensation in line with NPRA guidelines.
Source: PSWEPS Client Service Charter.

# PSWEPS — Contact Details

Address: Mezzanine Floor, Omanye Aba House (NDK Financial Services Building), No. 001, 28th February Road, Christiansborg Osu, Accra (opposite the Accra Sports Stadium).
Digital Address: GB-040-1152.
P.O. Box: MB 203, Ministries – Osu, Accra.
Phone / WhatsApp: +233 55 452 8198; +233 50 644 5203; +233 27 055 5203.
Email: info@psweps.gov.gh; support@psweps.gov.gh; chairperson@psweps.gov.gh; secretary@psweps.gov.gh.
Office hours: Monday–Friday, 8:30 a.m.–5:00 p.m. Closed weekends and public holidays.
Social: X/Twitter @psweps; Instagram @psweps_; Facebook "Public Sector Workers Employees Pension Scheme".
Regional offices: None documented — only the Osu, Accra secretariat.
Suspected fraud/corruption: Report to info@psweps.gov.gh or +233 (0)55 452 8198.
Source: PSWEPS Contact page; Client Service Charter; 2025 Annual Report.

# PSWEPS — Complaints & Escalation

Complaints are made via the Scheme website or contact channels.
Acknowledged within 24 hours; resolved within 3–5 working days.
Escalation ladder (Client Service Charter):
- Level 1: Initial resolution by the relevant officer or unit within the Secretariat.
- Level 2: Escalation to a relevant Committee of the Board.
- Level 3: Escalation to the Board of Trustees.
- Level 4: Escalation to an Independent body for external mediation — the NPRA.
Source: PSWEPS Client Service Charter.

# PSWEPS — Governance

Board of Trustees: 15 members. Nominated by Participating Institutions and Government, with an Independent Trustee. Representation from Government, the Trades Union Congress (TUC), and participating institutions.
Chairperson since inception: Mrs. Cynthia (Ayebo) Arthur.
Board Secretary: Ms. Philipina Akua Asare.
Independent Trustee: Mr. Victor Owusu (through 2024); Mr. Martin Luke-Tay (2025 board).
Board was reconstituted during 2025 (34th Board Meeting).
Four Board committees: Education; Finance and Audit; Investment and Risk; Legal. Board meets at least once every quarter.
Trustee responsibilities: Proper accounting records, IFRS-compliant financial statements per Act 766, Act 883, and L.I. 1990; safeguarding assets; fraud prevention/detection; internal controls.
Relationship with NPRA: PSWEPS is registered and regulated by the NPRA; NPRA is the Level-4 external mediation body for complaints.
NPRA ranking: PSWEPS is ranked 3rd among employer-sponsored occupational schemes by AUM market share (1.87%) per NPRA's 2023 Annual Report.
Annual General Meetings: 1st AGM Dec 2021; 2nd AGM 22 Aug 2024 (Accra International Conference Centre); 3rd AGM 27 Aug 2026 (Wesley Towers, Ridge).
Source: PSWEPS About pages; 2023/2024/2025 Annual Reports; NPRA 2023 Annual Report.

# PSWEPS — Service Providers (date-qualified)

Scheme (Fund) Administrator:
- 2023–2024: General Trust Company Limited (GENTRUST), 121/21 Saflo Link, Abelemkpe, Accra.
- 2025 onwards: Standard Pensions Trust Limited, 42 Nii Nortey Nyanchi Street, Dzorwulu.
Fund Managers:
- 2023–2024: Bora Capital Advisors Limited; SDC Capital Limited.
- 2025 onwards: Bora Capital Advisors Limited; Premium Place Investments Limited.
Custodian: Fidelity Bank Ghana Limited (all years).
Independent Auditor: Aryeetey & Associates (all years).
Important: Always date-qualify answers about "your administrator" or "your fund manager" — these changed.
Source: PSWEPS 2023/2024/2025 Annual Reports.

# PSWEPS — Investment Policy & Financial Trajectory

Investment policy: Governed by NPRA's asset allocation framework and PSWEPS's Statement of Investment Policy (SIP; drafted April 2018; not published).
Asset allocation (31 Dec 2025): GoG securities 70.66% (within 75% max), bank/money market 15.65%, ordinary shares 11.17%, corporate bonds 1.17%, collective investment schemes 0.56%, local govt/statutory agency 0.14%.
2023: GoG securities 91.06% (after DDEP participation).
AUM: GH¢686.68m (2022) → GH¢909.11m (2023, +32.39%) → GH¢1.21bn (2024) → GH¢1.50bn (2025, +23.93%).
Membership: 31,712 (2023) → 32,869 (2024) → 34,854 (2025).
Source: PSWEPS 2023/2024/2025 Annual Reports.

# PSWEPS — Transfer & Portability Rules

Accrued Tier 2 benefits are portable.
A worker changing employment may transfer accrued Tier 2 contributions to the new employer's scheme, or leave them with the previous scheme's trustees, subject to scheme rules.
Tier 2 and Tier 3 cannot be combined into one scheme.
PSWEPS processes transfer-in/transfer-out requests within **4 weeks** from receipt of a complete transfer request.
Transfer values are calculated in line with NPRA guidelines and the Pensions Act (Act 766 ss.100(6)–(9)).
In 2024, 579 members ported out. In 2025, 984 total exits included statutory retirement (907) and early retirement (22).
Source: PSWEPS Client Service Charter; Act 766; NPRA Pensions Digest; 2024/2025 audited financials.

# PSWEPS — Common Member Questions (verbatim from PSWEPS materials)

Are you a Contributor to PSWEPS?
- Register now and create an account with our Fund Administrator.
- Reconcile your monthly contributions on your statement with the deductions shown on your pay slip.
- Contact us immediately to address any discrepancies.

What is Tier 2 Pension Scheme?
- It is a mandatory, defined contribution scheme, funded by 5% of an employee's basic salary.
- The employer makes the deductions and pays to the Scheme on behalf of the employee, monthly.
- The Scheme pays a lump sum benefit to the contributor (or beneficiary) on retirement, death, or in the event a contributor is medically declared invalid.
- Total benefit received is made up of total paid-up monthly contributions, plus investment returns, less administrative charges.

Why join PSWEPS?
- We are constantly working to keep the passion of ensuring income security for our members after retirement.
- We provide an efficient platform for contributors to access their statements online at any time.
- We provide pension education to our members.
- We listen to the ideas and concerns of our members through frequent engagements.

PSWEPS motto: "Your Pension, Our Concern."
Source: PSWEPS Brochure 2025; Client Service Charter.

# PSWEPS — What PSWEPS Is NOT

PSWEPS is NOT a defined benefit scheme. It is a defined contribution scheme.
PSWEPS does NOT pay a monthly pension. It pays a lump sum.
PSWEPS is NOT managed by SSNIT. SSNIT manages Tier 1 only.
PSWEPS does NOT manage Tier 3.
PSWEPS is NOT in Uganda, Nigeria, Kenya, or any other country. It is in Ghana.
PSWEPS does NOT cover CLOGSAG members (they are under the Hedge scheme), Health Sector workers (Health Sector scheme), teachers (GES scheme), or Judicial Service staff (Judicial Service scheme).
PSWEPS does NOT cover Police, Immigration, Prisons, Security & Intelligence Agencies, or Fire Service (excluded by Act 1091).
PSWEPS cannot approve benefits, change contribution records, or authorize transactions without authorized human PSWEPS staff.

# PSWEPS — Legal References

National Pensions Act, 2008 (Act 766). Full text: https://psweps.gov.gh/wp-content/uploads/2026/03/NATIONAL-PENSIONS-ACT-2008-ACT-766.pdf
National Pensions (Amendment) Act, 2014 (Act 883). Assent 31 Dec 2014; age-50 exemption; s.73A non-Ghanaian benefit; penalty/enforcement amendments.
National Pensions (Amendment) Act, 2023 (Act 1091). Excludes Police, Immigration, Prisons, Security & Intelligence Agencies, and Fire Service from pension unification; amends ss.35 and 213 of Act 766. Hosted (mislabeled as "Act-766.pdf") at https://psweps.gov.gh/wp-content/uploads/2026/03/Act-766.pdf
Occupational and Personal Pension Schemes (General) Regulations, 2011 (L.I. 1990).
Key sections: s.100 (contributions), s.101 (benefit entitlement), s.102–103 (protection), s.104 (tax), s.106 (further provisions).
Source: PSWEPS National Pensions Act page; NPRA; BRR Ghana.

# PSWEPS — Background & Historical Notes

PSWEPS was established to consolidate public sector institutions that were without schemes at the time of the Temporary Pension Fund Account (TPFA) transfer.
The 2019 Budget Statement confirms the NPRA registered PSWEPS "to manage … residual funds in the public sector TPFA."
Tier 2 contributions had been held at the Bank of Ghana from January 2010 pending scheme registration.
2018 milestones: January — 15 Trustees inaugurated, Chairperson appointed. February — four service providers appointed. March — proportion of TPFA funds transferred from Bank of Ghana to the Scheme; Trust Deed and Scheme Rules drafted and finalised.
2020: NPRA directed an interim 80% benefit payment to 2020 public-sector retirees pending TPFA data resolution. PSWEPS began paying from 3 August 2020.
2021 (June): CLOGSAG publicly demanded PSWEPS be scrapped and transfers (allegedly GH¢53m and GH¢5m) reversed. No resolution recorded in PSWEPS publications.
Note on establishment year: A June 2021 GBC report (quoting CLOGSAG) described PSWEPS as "established by the Ministry of Finance in 2017." PSWEPS's own documents and NPRA registration say January 2018. Treat 2018 as authoritative; 2017 likely refers to pre-registration planning.
Source: PSWEPS 2023 Annual Report; 2019 Budget Statement para 852; Retirees Payments Communiqué; GBC Ghana Online (secondary).

# PSWEPS — Contact Channels for Missing Information

If a member asks about something not covered in this knowledge base — Scheme Rules, Trust Deed, Statement of Investment Policy, 2018–2022 annual reports, a specific institution's participation status, or a specific contribution record — the assistant should say:
"I don't have verified information on that — please contact PSWEPS at info@psweps.gov.gh or call +233 55 452 8198."
Source: PSWEPS Contact page.